import Ember from 'ember';

export default Ember.Route.extend({
  beforeModel() {
    const store = this.get('store');
    store.pushPayload({
      data: [
        {
          id: '1',
          type: 'klan',
          attributes: {
            name: 'Blood Axes',
            colors: 'Green and drab colours',
            'combat-specialty': 'Camouflage, Stealth',
            logo: 'https://vignette.wikia.nocookie.net/warhammer40k/images/5/5a/Blood_Axes_Icon.png/revision/latest?cb=20140726025402'
          },
          relationships: {
            warbosses: {
              data: [
                {id: '1', type: 'warboss'},
                {id: '2', type: 'warboss'},
                {id: '3', type: 'warboss'}
              ]
            }
          }
        },
        {
          id: '2',
          type: 'klan',
          attributes: {
            name: 'Goffs',
            colors: 'Black with checks and dags',
            'combat-specialty': 'Shock Assault',
            logo: 'https://vignette.wikia.nocookie.net/warhammer40k/images/a/aa/Goff_Icon.jpg/revision/latest?cb=20140713230526'
          },
          relationships: {
            warbosses: {
              data: [
                {id: '4', type: 'warboss'},
                {id: '5', type: 'warboss'},
                {id: '6', type: 'warboss'},
                {id: '7', type: 'warboss'}
              ]
            }
          }
        },
        {
          id: '3',
          type: 'klan',
          attributes: {
            name: 'Bad Moons',
            colors: 'Golden Yellow and Black',
            'combat-specialty': 'Ranged Combat, Dakka (Excessive Firepower)',
            logo: 'https://vignette.wikia.nocookie.net/warhammer40k/images/d/d9/Bad_Moon_Icon.png/revision/latest?cb=20140726221010'
          },
          relationships: {
            warbosses: {
              data: [
                {id: '8', type: 'warboss'},
                {id: '9', type: 'warboss'},
                {id: '10', type: 'warboss'},
                {id: '11', type: 'warboss'},
                {id: '12', type: 'warboss'},
                {id: '13', type: 'warboss'},
              ]
            }
          }
        }
      ]
    });
    store.pushPayload({
      data: [
        {
          id: '1',
          type: 'warboss',
          attributes: {
            name: 'Baddfrag the Tank Boss'
          }
        },
        {
          id: '2',
          type: 'warboss',
          attributes: {
            name: 'Snikrot'
          }
        },
        {
          id: '3',
          type: 'warboss',
          attributes: {
            name: 'Gorsnik Magash'
          }
        },
        {
          id: '4',
          type: 'warboss',
          attributes: {
            name: 'Ghazghkull Mag Uruk Thraka'
          }
        },
        {
          id: '5',
          type: 'warboss',
          attributes: {
            name: 'Goffboss Drogg'
          }
        },
        {
          id: '6',
          type: 'warboss',
          attributes: {
            name: 'Gutrak Dethhead'
          }
        },
        {
          id: '7',
          type: 'warboss',
          attributes: {
            name: 'Krugg'
          }
        },
        {
          id: '8',
          type: 'warboss',
          attributes: {
            name: 'Badrukk'
          }
        },
        {
          id: '9',
          type: 'warboss',
          attributes: {
            name: 'Big Mek Mogrok'
          }
        },
        {
          id: '10',
          type: 'warboss',
          attributes: {
            name: 'Gashrakk Da Flash'
          }
        },
        {
          id: '11',
          type: 'warboss',
          attributes: {
            name: 'Nazdreg Ug Urdgrub',
          }
        },
        {
          id: '12',
          type: 'warboss',
          attributes: {
            name: 'Nekkruncha'
          }
        },
        {
          id: '13',
          type: 'warboss',
          attributes: {
            name: 'Ozdakka'
          }
        }
      ]
    });
  }
});