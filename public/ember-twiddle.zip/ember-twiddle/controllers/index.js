import Ember from 'ember';
import SemanticUiTheme from '../themes/semanticui';

export default Ember.Controller.extend({
  themeInstance: SemanticUiTheme.create(),
  columns: [
    {component: 'expand-row', disableFiltering: true, mayBeHidden: false},
    {propertyName: 'id', sortedBy: 'idNumeric'},
    {propertyName: 'name'},
    {propertyName: 'colors'},
    {propertyName: 'combat-specialty'}
  ]
});
