import Ember from 'ember';
import Theme from '../themes/bootstrap3';

export default Ember.Controller.extend({
  themeInstance: Theme.create({sortGroupedPropertyBtn: 'btn btn-link'}),
  displayGroupedValueAs: Ember.computed('displayGroupedValueAsToggle', function () {
    return this.get('displayGroupedValueAsToggle') ? 'row' : 'column';
  }),
  currentGroupingPropertyName : 'createdDay',
  dataGroupProperties: [{value: 'user.login', label: 'User'}, {value: 'createdDay', label: 'Created Day'}],
  displayGroupedValueAsToggle: false,
  columns: [
    {
      component: 'select-toggle',
      useFilter: false,
      mayBeHidden: false
    },
    {
      component: 'expand-toggle',
      useFilter: false,
      mayBeHidden: false
    },
    {propertyName: 'id'},
    {propertyName: 'user.login', title: 'User'},
    {propertyName: 'created_at'},
    {propertyName: 'updated_at'}
  ]
});
