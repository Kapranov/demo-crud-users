import Ember from 'ember';
import DS from 'ember-data';

export default DS.JSONAPISerializer.extend({
  _mapIncluded(data, type) {
    const clb = item => ({id: item.id, type, attributes: item});
    return Ember.isArray(data) ? data.map(clb) : [clb(data)];
  },
  normalizeQueryResponse(a, b, payload) {
    const included = [];
    const newPayload = {
    	data: payload.map(item => {
        const itemData = {
        	id: item.id,
          type: 'comment',
          attributes: item,
          relationships: {
          	user: {
              data: { id: item.user.id, type: 'user' }
            }
          }
        };
        included.pushObjects(this._mapIncluded(item.user, 'user'));
        return itemData;
      })
    };
    newPayload.included = included;
    console.log(newPayload);
    return newPayload;
  }
});
