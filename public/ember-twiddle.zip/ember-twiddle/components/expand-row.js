import Ember from 'ember';

export default Ember.Component.extend({
  actions: {
    collapseRow(index, record) {
     this.get('collapseRow')(index, record);
    },
    expandRow(index, record) {
      this.get('expandRow')(index, record);
    }
  }
});
