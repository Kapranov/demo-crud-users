import Ember from 'ember';
import layout from '../templates/components/select-toggle';

export default Ember.Component.extend({
  layout,
  actions: {
    clickOnRow(index, record, event) {
      this.get('clickOnRow')(index, record);
      event.stopPropagation();
    }
  }
});
