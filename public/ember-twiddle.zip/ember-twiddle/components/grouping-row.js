import Ember from 'ember';
import DefaultComponent from './models-table/row-group-toggle';

export default DefaultComponent.extend({
  classNames: ['grouping-cell']
});
