import Ember from 'ember';
import SemanticUiTheme from 'app/themes/semanticui';

export default Ember.Component.extend({
  internalThemeInstance: SemanticUiTheme.extend({table: 'ui sortable selectable inverted table'}).create(),
  columns: [
    {propertyName: 'id', sortedBy: 'idNumeric'},
    {propertyName: 'name'}
  ]
});
