import layout from '../templates/components/expand-toggle';

export default Ember.Component.extend({
  layout,
  actions: {
    collapseRow(index, record) {
      this.get('collapseRow')(index, record);
    },
    expandRow(index, record) {
      this.get('expandRow')(index, record);
    }
  }
});
