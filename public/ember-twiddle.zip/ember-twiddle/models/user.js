import Model from "ember-data/model";
import attr from "ember-data/attr";
import { belongsTo, hasMany } from "ember-data/relationships";

export default Model.extend({
  login: attr('string'),
	avatar_url: attr('string'),
	url: attr('string'),
	html_url: attr('string'),
	type: attr('string'),
	site_admin: attr('boolean')
});