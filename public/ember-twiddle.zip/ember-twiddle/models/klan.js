import Ember from 'ember';
import Model from "ember-data/model";
import attr from "ember-data/attr";
import { belongsTo, hasMany } from "ember-data/relationships";

export default Model.extend({
  name: attr('string'),
  colors: attr('string'),
  'combat-specialty': attr('string'),
  logo: attr('string'),
  warbosses: hasMany('warboss'),
  idNumeric: Ember.computed('id', function () {
    return parseInt(this.get('id'), 10);
  })
});
