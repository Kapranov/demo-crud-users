import Model from "ember-data/model";
import attr from "ember-data/attr";
import { belongsTo, hasMany } from "ember-data/relationships";
import Ember from 'ember';

export default Model.extend({
  url: attr('string'),
	html_url: attr('string'),
	issue_url: attr('string'),
	user: belongsTo('user'),
	created_at: attr('string'),
	updated_at: attr('string'),
	author_association: attr('string'),
	body: attr('string'),
  createdDay: Ember.computed('created_at', function () {
    const d = new Date(this.get('created_at'));
    let month = d.getMonth();
    month = (month < 10 ? '0': '') + month;
    let day = d.getDate();
    day = (day < 10 ? '0' : '') + day;
    return `${d.getFullYear()}-${month}-${day}`;
  })
});