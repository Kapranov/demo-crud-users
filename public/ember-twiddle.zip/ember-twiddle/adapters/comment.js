import DS from 'ember-data';

export default DS.RESTAdapter.extend({
  host: 'https://api.github.com',
  namespace: 'repos/emberjs/ember.js/issues/13071/comments',
  query(store, b, query) {
    const url = `${this.get('host')}/${this.get('namespace')}`;
    return this.ajax(url, 'GET', {data: query}); 
  }
});
